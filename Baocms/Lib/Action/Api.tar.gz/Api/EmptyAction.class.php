<?php
class EmptyAction extends BaseAction
{

}